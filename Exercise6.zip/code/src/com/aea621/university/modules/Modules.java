package com.aea621.university.modules;
public class Modules {
	private String modName;
	private String lecName;
	private String modCode;
	
	public Modules (String name, String mod,String lec){
		modName = name;
		lecName = lec;
		modCode = mod;
}

		public String getModName(){
		  String alphaRegex = ".*[A-Z].*";
	  	if(modName.matches(alphaRegex)){
			return modName;
		}
		return "Error this is an invalid module name";
	}
	 	public String getLecName(){
	 	   String alphaRegex = ".*[A-Z].*";
	  	if(lecName.matches(alphaRegex)){
			return lecName;
		}
		return "Error this is an invalid Lecturer's name";
	}
	    public String getModCode(){
	    	String alphaRegex = ".*[A-Z].*";
	  	if(modCode.matches(alphaRegex)){
			return modCode;
		}
		return "Error this is an invalid module code";
	}

	public String toString(){
		String moduleinfo = " ";
		moduleinfo += "The Module name: " + getModName() + "\n";  
		moduleinfo += "Lecturer's name: " + getLecName() + "\n";
		moduleinfo += "Module code: " + getModCode() + "\n";
	 	return moduleinfo;
	 }

}
