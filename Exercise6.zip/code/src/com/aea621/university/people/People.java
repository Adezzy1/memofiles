package com.aea621.university.people;
import java.util.ArrayList;
public class People{
	protected String name;
	protected int idnumber;
	protected String address;
	protected String emailAddress;

	public People(String name, String address, String email, int id){
		this.name = name;
		this.address = address;
		this.emailAddress = email;
		this.idnumber = id;
}
	  public String getName(){
	  	String alphaRegex = ".*[A-Z].*";
	  	if(name.matches(alphaRegex)){
			return name;
		}
		return "Error this is an invalid name";
	}
		
		
	 
	public String getAddress(){
		String alphaRegex = ".*[A-Z].*";
	  	if(address.matches(alphaRegex)){
			return address;
		}
		return "Error this is an invalid address name";
	}
		 
	public void setAddress(String address){
			this.address=address;
		}

	public String getEmailAddress(){
		String alphaRegex = ".*[A-Z].*";
		String numRegex = ".*[0-9].*";
	  	if(emailAddress.matches(alphaRegex) && emailAddress.matches(numRegex)){
			return emailAddress;
		}
		return "Error this is an invalid EmailAddress";
	}
	
	 public int getIdnumber(){
	 	return idnumber;
	}
	 public String toString(){
	 	String studentsinfo = " ";
	 	studentsinfo += "Person name: " + getName() + "\n"; 
	 	studentsinfo += "Idnumber: " + getIdnumber() +  "\n";
	 	studentsinfo += "Address:  " + getAddress() + "\n";
	 	studentsinfo += "Emailaddress: " + getEmailAddress() + "\n";
	 	return studentsinfo;
	 }


}
