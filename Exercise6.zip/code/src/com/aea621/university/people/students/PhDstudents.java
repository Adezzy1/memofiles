package com.aea621.university.people.students;
import com.aea621.university.people.staff.*;
public class PhDstudents extends Students{
	private String superVisor;

    public PhDstudents(String name, String address, String email,int idnumber, String superVisor, String personalTutor){
    	super(name, address, email,personalTutor,idnumber);
    	this.superVisor = superVisor;
    }

    public String getSuperVisor(){
       String alphaRegex = ".*[A-Z].*";
	  	if(superVisor.matches(alphaRegex)){
			return superVisor;
		}
		return "Error this is an invalid superVisor's name";
	}
	
	
     // overides the toString() method in the People class
	 public String toString(){
	 	String  phDstudentsinfo = " ";
	 	phDstudentsinfo += "The student's name: " + super.getName() + "\n";
	 	phDstudentsinfo += "The student's Idnumber: "+ super.getIdnumber() + "\n"; 
	 	phDstudentsinfo += "Student's address: " + super.getAddress() + "\n"; 
	 	phDstudentsinfo += "Student's emailaddress: "+ super.getEmailAddress() + "\n"; 
	 	phDstudentsinfo += "Personal Tutor's name: " + getPersonalTutor() + "\n";
	    phDstudentsinfo += "superVisor's name: " + getSuperVisor() + "\n";
			return  phDstudentsinfo;
		}
 

}
