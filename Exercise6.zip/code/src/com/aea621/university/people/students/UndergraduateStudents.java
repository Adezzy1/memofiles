package com.aea621.university.people.students;
import com.aea621.university.people.staff.*;
public class UndergraduateStudents extends Students{


	public UndergraduateStudents(String name, String address, String email,String personalTutor,int idnumber){
    	super(name, address, email,personalTutor,idnumber);

 }



  // overides the toString() method in the Students class
  public String toString(){
	 	String undergraduateStudentsinfo = " ";
	 	undergraduateStudentsinfo += "The student's name:" + super.getName() + "\n";
	    undergraduateStudentsinfo += "The student's Idnumber: "+ super.getIdnumber() + "\n";  
	 	undergraduateStudentsinfo += "Student's address  name: " + super.getAddress() + "\n";
	 	undergraduateStudentsinfo += "Student's emailaddress: "+ super.getEmailAddress() + "\n"; 
	 	undergraduateStudentsinfo += "Personal Tutor's name: " + super.getPersonalTutor() + "\n";
			return undergraduateStudentsinfo;
		}

 




}
