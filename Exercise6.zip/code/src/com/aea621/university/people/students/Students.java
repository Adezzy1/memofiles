package com.aea621.university.people.students;
import com.aea621.university.modules.*;
import com.aea621.university.people.*;
import com.aea621.university.people.staff.*;
import java.util.ArrayList;
public class Students extends People{
    protected String personalTutor;
    protected ArrayList<Modules> module=new ArrayList<Modules>();

    public Students(String name, String address, String email, String personalTutor, int idnumber){
    	super(name, address, email,idnumber);
    	this.personalTutor = personalTutor;
    }

    public String getPersonalTutor(){
       String alphaRegex = ".*[A-Z].*";
	  	if(personalTutor.matches(alphaRegex)){
			return personalTutor;
		}
		return "Error this is an invalid personalTutor's name";
	}

    public void addModules(Modules mod){
    	module.add(mod);

    }
    public void removeModules(Modules mod){
    	module.remove(mod);
    }

    public ArrayList<Modules> getModules(){
    		return module;
    }


  // overides the toString() method in the People class
	 public String toString(){
	 	String studentsinfo = " ";
	 	studentsinfo += "The student's name: " + super.getName() + "\n";
	 	studentsinfo += "The student's Idnumber: "+ super.getIdnumber() + "\n";  
	 	studentsinfo += "Student's address  name: " + super.getAddress() + "\n";
	 	studentsinfo += "Student's emailaddress: "+ super.getEmailAddress() + "\n"; 
	 	studentsinfo += "Personal Tutor's name is: " + getPersonalTutor() + "\n";
			return studentsinfo;
		}

}

			