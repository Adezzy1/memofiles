package com.aea621.university.people.staff;
import com.aea621.university.people.*;
public class Staffs extends People{
	protected int officenumber;
	protected String phonenumber;


	public Staffs(String name, String address, String email, String phonenumber, int officenumber, int id){
		super(name, address, email, id);
		this.officenumber = officenumber;
		this.phonenumber = phonenumber;
	}

	 String numRegex = ".*[0-9].*";
	 String alphaRegex = ".*[A-Z].*";


		public int getOfficeNumber(){
			return officenumber;	
	}

		public String getPhoneNumber(){
	  	if(phonenumber.length() == 11 && phonenumber.matches(numRegex)){
			return phonenumber;
		}
		return "Error this is an invalid phonenumber";
	}

		public void setPhonenumber(String phonenumber){
			this.phonenumber=phonenumber;
		}

		public void setOfficenumber(int officenumber){
			this.officenumber=officenumber;
		}

// overides the toString() method in the  people class
	 public String toString(){
	 	String staffinfo = " ";
	 	staffinfo += "The Staff's name: " + super.getName() + "\n";
	 	staffinfo += "Idnumber: "+ super.getIdnumber() + "\n"; 
	 	staffinfo += "Address: " + super.getAddress() + "\n"; 
	 	staffinfo += "Emailaddress: "+ super.getEmailAddress() + "\n"; 
	 	staffinfo += "Phonenumber: " + getPhoneNumber() + "\n";
	    staffinfo += "Officenumber: " + getOfficeNumber() + "\n";
			return staffinfo;
		}

}
