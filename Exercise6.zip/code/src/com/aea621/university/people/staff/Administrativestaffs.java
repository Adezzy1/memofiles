package com.aea621.university.people.staff;
public class Administrativestaffs extends Staffs{
	private String area;
	
	public Administrativestaffs(String name, int id, String address, String email, String phonenumber, int officenumber, String area){
		super(name,address,email,phonenumber,officenumber,id);
		this.area= area;
	}
	public String getArea(){
		String alphaRegex = ".*[A-Z].*";
	  	if(area.matches(alphaRegex)){
			return area;
		}
		return "Error this is an invalid admin area";
	}

	public void setArea(String area){
			this.area=area;
		}
// overides the toString() method in the  Staff class
    public String toString(){
    	String administrativeinfo = " ";
	 	administrativeinfo += "The Administrative Staff's name: " + super.getName() + "\n";
	 	administrativeinfo += "The Administrative Staffs's Idnumber: "+ super.getIdnumber() + "\n"; 
	 	administrativeinfo += "Address: " + super.getAddress() + "\n"; 
	 	administrativeinfo += "Emailaddress: "+ super.getEmailAddress() + "\n"; 
	 	administrativeinfo += "Phonenumber: " + super.getPhoneNumber() + "\n";
	    administrativeinfo += "Officenumber: " + super.getOfficeNumber() + "\n";
	    administrativeinfo += "Administrative Area: " + getArea() + "\n";
			return administrativeinfo;
		}
}
