package com.aea621.university.people.staff;
import java.util.ArrayList;
import com.aea621.university.modules.*;
public class Lecturingstaffs extends Staffs{
	private String researchArea;
	private ArrayList<Modules> module=new ArrayList<Modules>();

	public Lecturingstaffs( String name, int id,String address, String email, String phonenumber, int officenumber, String researchArea){
		super(name,address,email,phonenumber,officenumber, id);
		this.researchArea= researchArea;
	}
  
  	public String getResearcharea(){
  		String alphaRegex = ".*[A-Z].*";
	  	if(researchArea.matches(alphaRegex)){
			return researchArea;
		}
		return "Error this is an invalid researchArea name";
	}
  
  	public void setResearchArea(String area){
			this.researchArea=area;
		}
	

	 public void addModules(Modules mod){
    	module.add(mod);

    }
    public void removeModules(Modules mod){
    	module.remove(mod);
    }

    public ArrayList<Modules> getModules(){
    		return module;
    }
      String numRegex = ".*[0-9].*";
    public String getPhoneNumber(){
		String alphaRegex = ".*[A-Z].*";
	  	if(phonenumber.matches(alphaRegex)){
			return phonenumber;
		}
		return "Error this is an invalid Phonenumber";
	}

    public String toString(){
    	String lecturingstaffsinfo = " ";
	 	lecturingstaffsinfo += "The Lecturing Staff's name: " + super.name + "\n";
	 	lecturingstaffsinfo += "Idnumber: "+ super.getIdnumber() + "\n"; 
	 	lecturingstaffsinfo += "Address: " + super.getAddress() + "\n"; 
	 	lecturingstaffsinfo += "Emailaddress: "+ super.getEmailAddress() + "\n"; 
	 	lecturingstaffsinfo += "Phonenumber: " + super.getPhoneNumber() + "\n";
	    lecturingstaffsinfo += "Officenumber: " + super.getOfficeNumber() + "\n";
	    lecturingstaffsinfo += "ResearchArea: " + getResearcharea() + "\n";
			return lecturingstaffsinfo;
		}
	
	
   }



	
