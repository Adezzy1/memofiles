package com.aea621.universitytest;
import com.aea621.university.modules.*;
import com.aea621.university.people.staff.*;
import com.aea621.university.people.students.*;
import com.aea621.university.people.*;

public class UniversityTest{
	public static void main (String[] args){



  //Testing the module class
		Modules m1 = new Modules("Geography", "GE124", "Mr Peter Jones");
     	System.out.println(m1.toString());

     	Modules m2 = new Modules("Physics", "PH974", "Mr James Pocker");
     	System.out.println(m2.toString());

     	Modules m3 = new Modules("English", "EN754", "Mrs Mary Jane");
     	System.out.println(m3.toString());

        //Test m4 is to check for the validation if it returns empty for an empty strings
        Modules m4 = new Modules(" ", " ", " ");
        System.out.println(m4.toString());

        Modules m5 = new Modules("Account", "AC968", "Mrs Mary Jane");
        System.out.println(m5.toString());

        Modules m6 = new Modules("Computer", "CO572", "Mr Yuji Xui");
        System.out.println(m6.toString());

        Modules m7 = new Modules("Math", "MA573", "Mr Lorrie Borne");
        System.out.println(m7.toString());
        
        Modules m8 = new Modules("Artificial Intelligence", "AI593", "Mr John Stone");
        System.out.println(m8.toString());
        // Testing m9 is to check validation when and integer is typed instead of a string as module name and empty strings
        Modules m9 = new Modules("1426", "        ", "");
        System.out.println(m9.toString());



  //Testing the People class
     	People p1 = new People("Ali Baba", "maple bank in the vale.Birmingham", "Aliden1@gamil.com", 1704211);
        p1.setAddress("maple bank in the vale");
        String i1 = p1.getAddress();
     	System.out.println(p1.toString());

     	People p2 = new People("Joe Peter", "New street", "Joepark2@gamil.com", 1704212);
        p2.setAddress("Church road. New street");
        String i2 = p2.getAddress();
     	System.out.println(p2.toString());

        People p3 = new People("Mr James Range", "Sally Oak", "James4@gamil.com", 1704190);
        p3.setAddress("Flat 12 Sally Oak");
        String i3 = p3.getAddress();
        System.out.println(p3.toString());

     	People p4 = new People("Mrs Mary Stephan", "Flat 1 Victoria Hall.Birmingham", "Marykain3@gamil.com", 1209346);
        p4.setAddress("Victoria Hall");
        String i4 = p4.getAddress();
     	System.out.println(p4.toString());

        //Test p5 is to check for the validation for an empty strings
        People p5 = new People(" ", "419" , " ", 123);
        System.out.println(p5.toString());



  //Testing the students class
     	Students s1 = new Students("Mark Joke", "The vale tennis court.Birmingham", "Markras3@hotmail.com", "Mr Potter Venus", 1703456);
     	s1.addModules(m1);
        s1.addModules(m2);
        System.out.println(s1.toString());
        System.out.println("Mark Joke has been added to " + s1.getModules());  
        
    
        System.out.println(" ");
        Students s2 = new Students("Joe Bellon", "The vale maple bank block 5.Birmingham", "Joepark3@gamil.com", "Mr John Zebb", 1704212);
        s2.addModules(m3);
        s2.addModules(m2);
        System.out.println(s2.toString());
        System.out.println("Joe Bellon has been added to " + s2.getModules());

        System.out.println(" ");
	    Students s3 = new Students("Adeola Aderibigbe", "The vale Block 1 maple bank ", "Adeolae1@gamil.com", "Mr Harry Potter", 1704219);
    	s3.addModules(m1);
        s3.addModules(m3);
        System.out.println(s3.toString());
        System.out.println("Adeola Aderibigbe has been added to " + s3.getModules());

        System.out.println(" ");
        //Test s4 is to check for the validation for an empty string
        Students s4 = new Students("      ", " ", " ", " ", 1704219);
        s4.addModules(m2);
        System.out.println(s4.toString());
        System.out.println(" " + s4.getModules());

        System.out.println(" ");     
 //Testing the Undergraduatestudents class
     	UndergraduateStudents u1 = new UndergraduateStudents("Lili Walker",  "Flat 40 Sally Oak", "Lili3@hotmail.com", "Mrs Mary James", 1704210);
     	u1.addModules(m1);
        u1.addModules(m2);
        u1.addModules(m3);
        System.out.println(u1.toString());
        System.out.println("Lili Walker has been added to " + u1.getModules());

        System.out.println(" ");
		UndergraduateStudents u2 = new UndergraduateStudents("Bella Nanny", "Flat 1 Sally Oak", "Bella5@gamil.com", "Mr Harry Potter", 1704216);
     	u2.addModules(m2);
        u2.addModules(m1);
        System.out.println(u2.toString());
        System.out.println("Bella Nanny has been added to " +u2.getModules());

        System.out.println(" ");
     	UndergraduateStudents u3 = new UndergraduateStudents("Randy Spake", "The Vale Block 9 maple bank", "Randyk6@hotmail.com", "Mrs Mary James", 1704217);
        u3.addModules(m2);
        u3.addModules(m1);
        u3.addModules(m7);
        System.out.println(u3.toString());
        System.out.println("Randy Spake has been added to " +u3.getModules());
      
      //Test d4 is to check for the validation that the strings must never be empty of non white space characters
        System.out.println(" ");
        UndergraduateStudents u4 = new UndergraduateStudents(" ", " ", " ", " ", 1704217);
        u4.addModules(m5);
        u4.addModules(m7);
        System.out.println(u4.toString());
        System.out.println(" " +u4.getModules());
        System.out.println(" "); 

  //Testing the PhDstudents class
     	PhDstudents d1 = new PhDstudents("Simon Ade", "Flat 103 Sally Oak", "Simon4@hotamil.com", 1801110, "Mrs Bruce Almighty","Mr Jark Spoon");
        d1.addModules(m1);
        d1.addModules(m5);
        System.out.println(d1.toString());
        System.out.println("Simon Ade has been added to " +d1.getModules());

        System.out.println(" ");
		PhDstudents d2 = new PhDstudents("Berry Alen", "Flat 300 Sally Oak", "Betty7@gamil.com",  1801111, "Mr Harry Potter", "Mr Clark Davison");
     	d2.addModules(m2);
        d2.addModules(m6);
        System.out.println(d2.toString());
        System.out.println("Berry Alen has been added to " +d2.getModules());

        System.out.println(" ");
     	PhDstudents d3 = new PhDstudents("Mill Yope", "New Street", "Mill4@gmail.com", 1801112, "Mrs Hope Johnson","Mr David Bekan");
     	d3.addModules(m3);
        d3.addModules(m1);
        System.out.println(d3.toString());
        System.out.println("Mill Yope has been added to " +d3.getModules());

        System.out.println(" ");
        //Test d4 is to check for the validation that the strings must never be empty of non white space characters
        PhDstudents d4 = new PhDstudents(" ", " ", " ", 3574126, " "," ");
        d4.addModules(m3);
        d4.addModules(m1);
        System.out.println(d4.toString());
        System.out.println(" " +d4.getModules());

        System.out.println(" ");
   //Testing the staff class
        Staffs f1 = new Staffs("Mr James Pocker","The Abbey street Cross country road" , "James9@gamil.com", "070443304", 126, 145);
        f1.setOfficenumber(145);
        int i = f1.getOfficeNumber();
        f1.setPhonenumber("07044330412");
        String j = f1.getPhoneNumber();
        System.out.println(f1.toString());

        Staffs f2 = new Staffs("Mrs Mary Grace", "New street st paul road", "Marykain4@gamil.com", "070983254", 125,  301);
        f2.setOfficenumber(144);
        int k = f2.getOfficeNumber();
        f2.setPhonenumber("07098363264");
        String l = f2.getPhoneNumber();
        System.out.println(f2.toString());

        Staffs f3 = new Staffs("Mrs Love Stephan", "Flat 202 Victoria Hall" , "Lovexs3@gamil.com", "07448406192", 127, 145);
        f3.setOfficenumber(143);
        int y = f3.getOfficeNumber();
        f3.setPhonenumber("07448407548");
        String x = f3.getPhoneNumber();
        System.out.println(f3.toString());

        //Test f4 is to check for the validation if it returns empty for an empty strings
        Staffs f4 = new Staffs(" ", " " , " ", " ", 127, 145);
        f3.setOfficenumber(143);
        int y1 = f4.getOfficeNumber();
        f3.setPhonenumber(" ");
        String x1 = f4.getPhoneNumber();
        System.out.println(f4.toString());


    //Testing the lecturing
        Lecturingstaffs r1 = new Lecturingstaffs("Mr Yuji Xui", 111, "Flat 202 Victoria Hall" , "Yuji6@gamil.com", "+44479653421", 157, "Computer");
        r1.setOfficenumber(143);
        int s = r1.getOfficeNumber();
        r1.setPhonenumber("074484061257");
        String q = r1.getPhoneNumber();
        r1.setResearchArea("Computer");
        String z7 = r1.getResearcharea();
        System.out.println(r1.toString());
        
        Lecturingstaffs r2 = new Lecturingstaffs("Mrs Mary Jane", 112, "Flat 9 Victoria Hall" , "Jurie9@gamil.com", "07413254136", 159, "English");
        r2.setOfficenumber(143);
        int w = r2.getOfficeNumber();
        r2.setPhonenumber("076653257276");
        String w1 = r2.getPhoneNumber();
        r2.addModules(m6);
        r2.setResearchArea("English");
        String z8 = r2.getResearcharea();
        System.out.println(r2.toString());
        System.out.println("Mrs Mary Jane has been added to the module " + r2.getModules());

        System.out.println(" ");

        //Test r3 is to check for the validation if it returns empty for an empty strings
        Lecturingstaffs r3 = new Lecturingstaffs(" ", 112, " " , " ", " ", 159, " ");
        r3.setOfficenumber(143);
        int w8 = r3.getOfficeNumber();
        r3.setPhonenumber(" ");
        String w2 = r3.getPhoneNumber();
        r3.setResearchArea(" ");
        String z9 = r3.getResearcharea();
        System.out.println(r3.toString());


    //Testing the administrativestaffs class
        Administrativestaffs n1 = new Administrativestaffs ("Mr Mark Mojoka", 210, "Flat 2 Sally Oak" , "Mark4@gamil.com", "+446321325", 978, "Reception");
        n1.setOfficenumber(133);
        int a = n1.getOfficeNumber();
        n1.setPhonenumber("44635782372");
        String b = n1.getPhoneNumber();
        n1.setArea("Reception");
        String z3 = n1.getArea();
        System.out.println(n1.toString());

        
        System.out.println(" ");

        Administrativestaffs n2 = new Administrativestaffs ("Mr Sammy Login", 211, "Flat 96 Victoria Hall" , "Sammy7@gamil.com", "0713876539", 977, "Quality Assurance Manager");
        n2.setOfficenumber(134);
        int z = n2.getOfficeNumber();
        n2.setPhonenumber("07582763582");
        String z1 = n2.getPhoneNumber();
        n2.setArea("Assurance Manager");
        String z2 = n2.getArea();
        System.out.println(n2.toString());

        //Test n3 is to check for the validation if it returns empty for an empty strings
        Administrativestaffs n3 = new Administrativestaffs ("  ", 211, " " , " ", " ", 977, " ");
        n2.setOfficenumber(134);
        int z5 = n3.getOfficeNumber();
        n3.setPhonenumber(" ");
        String x9 = n3.getPhoneNumber();
        n3.setArea(" ");
        String x2 = n3.getArea();
        System.out.println(n3.toString());


  }
}

